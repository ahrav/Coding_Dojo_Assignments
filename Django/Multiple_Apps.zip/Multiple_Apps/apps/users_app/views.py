from django.shortcuts import render, HttpResponse, redirect

# Create your views here.
def display(requests):
    response = "placeholder for users to create a new user record"
    return HttpResponse(response)

def login(requests):
    response = " placeholder fo users to login"
    rturn HttpResponse(response)
